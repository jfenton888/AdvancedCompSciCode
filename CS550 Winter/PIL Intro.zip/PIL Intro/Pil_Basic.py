from PIL import Image, ImageFilter
import numpy as np

pixels = np.asarray(Image.open('BernerPuppies.jpg'))


avg = pixels.mean(axis=2)
pixels = Image.fromarray(np.uint8(((pixels+25)*-1)*2))

pixels = pixels.filter(ImageFilter.EDGE_ENHANCE)

pixels.show()

pixels.save('ChowPuppy_butdifferent.png')